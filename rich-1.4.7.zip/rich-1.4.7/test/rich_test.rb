require 'test_helper'

class RichTest < ActiveSupport::TestCase
  test "truth" do
    assert_kind_of Module, Rich
  end
end
