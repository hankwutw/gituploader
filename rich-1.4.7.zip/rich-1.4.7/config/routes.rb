Rich::Engine.routes.draw do
  
  resources :files, :controller => "files"
  
end
