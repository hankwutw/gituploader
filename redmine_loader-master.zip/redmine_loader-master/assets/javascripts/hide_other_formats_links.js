$(document).ready(function(){
  $(".other-formats")[0].style.display = "none"
});
