module Rich
  VERSION = "1.4.8"
end
