require 'test_helper'

module Rich
  class FilesHelperTest < ActionView::TestCase
  end
end
