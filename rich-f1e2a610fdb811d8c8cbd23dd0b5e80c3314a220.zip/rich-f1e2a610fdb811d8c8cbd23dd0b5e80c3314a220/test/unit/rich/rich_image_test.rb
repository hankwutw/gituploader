require 'test_helper'

module Rich
  class RichImageTest < ActiveSupport::TestCase
    # test "the truth" do
    #   assert true
    # end
  end
end
