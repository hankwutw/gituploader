redmine_issue_tabs
==================

Redmine plugin that enhances issue interface by adding several useful tabs: timelog, time spent, code commits, history
Changelog
  1.2.2:
    * Fixed: PG sql compatibility
  1.2.1:
    * Fixed: LB compatibility
  1.2.0:
    * Added: ajax issue history
  1.1.1:
    * fix double tabs in issues page
  1.1.0:
    * support Redmine 3.0
    * fixed rights for timelog page