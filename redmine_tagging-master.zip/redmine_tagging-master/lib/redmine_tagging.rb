module RedmineTagging
end

require 'redmine_tagging/patches/issue_patch'
require 'redmine_tagging/patches/project_patch'
require 'redmine_tagging/patches/query_patch'
require 'redmine_tagging/patches/wiki_page_patch'
require 'redmine_tagging/patches/queries_helper_patch'
require 'redmine_tagging/patches/application_controller_patch'
